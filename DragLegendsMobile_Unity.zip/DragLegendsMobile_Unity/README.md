# Drag Legends Mobile — Unity 3D Project

A self-contained, asset-free Unity project starter for an offline 3D drag-racing game. It creates the scene and UI at runtime, so you do not need to manually build a scene or import paid assets.

## Recommended environment
- Unity Hub + Unity **2022.3 LTS** (or newer Unity 2022/2023 LTS)
- Android Build Support installed (Android SDK/NDK + OpenJDK via Unity Hub)
- Windows/macOS/Linux computer for building the APK

## Open and build
1. Extract `DragLegendsMobile_Unity.zip`.
2. In Unity Hub choose **Add > Add project from disk** and select the extracted `DragLegendsMobile_Unity` folder.
3. Open the project and allow Unity to import scripts.
4. Open `Assets/Scenes/Bootstrap.unity` if it is not already open.
5. Press **Play** to test in the Editor.
6. For Android: `File > Build Settings` (or `Build Profiles` in newer Unity) > Android > Switch Platform.
7. In Player Settings:
   - Company Name: `YourStudio`
   - Product Name: `Drag Legends Mobile`
   - Package Name: `com.yourstudio.draglegendsmobile`
   - Orientation: Landscape Left
   - Minimum API: Android 7.0 / API 24 or higher
8. Add `Assets/Scenes/Bootstrap.unity` to Scenes In Build.
9. Connect an Android device or choose **Build** to create an APK.

## Controls
- Editor: hold **W / Up Arrow** to accelerate, **S / Down Arrow** to brake, **A/D** or **Left/Right** to steer, **Space** for nitro.
- Mobile: use the on-screen GAS, BRAKE, LEFT, RIGHT and NITRO controls.
- The game is designed for landscape orientation.

## Included
- Runtime-generated 3D drag strip, barriers, lights, finish line, sky and lighting
- Player and AI rival cars made from procedural primitives (no external art assets)
- Countdown, launch timing, speed display, nitro, distance/progress, finish and results screen
- Main menu, quick race, garage, car selection, upgrade shop, stats and settings panels
- Saved credits, selected car, upgrades, races and wins using PlayerPrefs
- Touch UI and keyboard controls
- Offline single-player racing

## Honest limitations
This is a playable, self-contained **prototype foundation**, not a finished AAA commercial release. Cars, environment and UI art are generated from primitives and gradients; there are no licensed car models, high-resolution track textures, authored engine recordings, online multiplayer backend, ads, analytics, IAP, cloud saves or anti-cheat. Those require additional assets/services and testing. The code is provided so you can build on it without missing external dependencies.

## Troubleshooting
- If TextMeshPro asks to import essentials, import them; this project uses built-in `UnityEngine.UI` text instead.
- If Android build tools are missing, open Unity Hub > Installs > your Unity version > Add modules > Android Build Support.
- If you see a blank scene, make sure `Assets/Scenes/Bootstrap.unity` is included in Scenes In Build and has `DragLegendsBootstrap` on the Bootstrap object.
