using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class DragLegendsBootstrap : MonoBehaviour
{
    public static DragLegendsBootstrap I;
    public enum Screen { Menu, Race, Garage, Upgrades, Stats, Settings, Results }
    public Screen currentScreen = Screen.Menu;

    [Header("Runtime state")]
    public int credits = 2500;
    public int selectedCar = 0;
    public int engineLevel = 1, gripLevel = 1, nitroLevel = 1;
    public int races = 0, wins = 0;
    public float raceLength = 700f;
    public bool soundOn = true;
    public bool raceRunning, raceFinished;
    public float elapsed, playerDistance, rivalDistance;
    public float playerSpeed, rivalSpeed;
    public float nitroFuel = 1f;
    public bool nitroHeld;
    public int launchScore;
    public string resultMessage = "";

    Camera cam;
    Canvas canvas;
    Font font;
    GameObject worldRoot, playerCar, rivalCar, road;
    Transform playerTransform, rivalTransform;
    Text hudSpeed, hudProgress, hudCountdown, hudNitro, hudTimer;
    Text titleText;
    GameObject raceHud, panelRoot, menuRoot;
    Button gasButton, brakeButton, leftButton, rightButton, nitroButton;
    bool gasHeld, brakeHeld, leftHeld, rightHeld;
    float steer;
    float countdown = -1f;
    float startTime;
    Vector3 playerStart = new Vector3(-2f, .4f, 0f);
    Vector3 rivalStart = new Vector3(2f, .4f, 0f);
    string[] carNames = { "Vortex GT", "Street Phantom", "Neon RS", "Desert Wolf" };
    Color[] carColors = { new Color(.03f,.32f,1f), new Color(.9f,.08f,.1f), new Color(1f,.55f,.03f), new Color(.78f,.82f,.9f) };

    void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        Application.targetFrameRate = 60;
        UnityEngine.Screen.sleepTimeout = SleepTimeout.NeverSleep;
        LoadData();
        SetupFont();
        SetupCamera();
        SetupWorld();
        SetupUI();
        ShowScreen(Screen.Menu);
    }

    void Update()
    {
        if (currentScreen == Screen.Race && !raceFinished)
        {
            UpdateRace();
        }
        if (currentScreen == Screen.Race)
        {
            if (Input.GetKeyDown(KeyCode.Escape)) ShowScreen(Screen.Menu);
        }
    }

    void SetupFont()
    {
        font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        if (font == null) font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
    }

    void SetupCamera()
    {
        cam = Camera.main;
        if (cam == null) { GameObject c = new GameObject("Main Camera"); cam = c.AddComponent<Camera>(); c.tag = "MainCamera"; }
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(.015f,.035f,.09f);
        cam.fieldOfView = 58f;
        cam.transform.position = new Vector3(0, 6.5f, -10f);
        cam.transform.rotation = Quaternion.Euler(20f, 0f, 0f);
        RenderSettings.ambientLight = new Color(.55f,.62f,.78f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(.025f,.045f,.1f);
        RenderSettings.fogDensity = .008f;
        GameObject light = new GameObject("Key Light");
        Light l = light.AddComponent<Light>();
        l.type = LightType.Directional;
        l.intensity = 1.25f;
        light.transform.rotation = Quaternion.Euler(48f,-28f,0f);
    }

    Material Mat(Color c, float metallic=0f, float smooth=.4f)
    {
        Shader sh = Shader.Find("Standard");
        Material m = new Material(sh);
        m.color = c; m.SetFloat("_Metallic", metallic); m.SetFloat("_Glossiness", smooth);
        return m;
    }

    GameObject Cube(string name, Vector3 pos, Vector3 scale, Color color, Transform parent=null)
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name=name; g.transform.position=pos; g.transform.localScale=scale;
        if (parent != null) g.transform.SetParent(parent, true);
        g.GetComponent<Renderer>().material=Mat(color, .15f, .45f);
        return g;
    }

    void SetupWorld()
    {
        worldRoot = new GameObject("Procedural Race World");
        Cube("Ground", new Vector3(0,-.35f,360), new Vector3(70,.5f,900), new Color(.025f,.055f,.09f), worldRoot.transform);
        road = Cube("Drag Strip", new Vector3(0,-.05f,360), new Vector3(12,.2f,900), new Color(.055f,.065f,.085f), worldRoot.transform);
        for (int z=0; z<900; z+=12)
        {
            Cube("Lane Dash L", new Vector3(-.08f,.065f,z), new Vector3(.12f,.025f,5f), new Color(.6f,.72f,.85f), worldRoot.transform);
            Cube("Lane Dash R", new Vector3(.08f,.065f,z), new Vector3(.12f,.025f,5f), new Color(.6f,.72f,.85f), worldRoot.transform);
        }
        Cube("Left Barrier", new Vector3(-6.5f,.35f,360), new Vector3(.35f,.8f,900), new Color(.03f,.18f,.35f), worldRoot.transform);
        Cube("Right Barrier", new Vector3(6.5f,.35f,360), new Vector3(.35f,.8f,900), new Color(.03f,.18f,.35f), worldRoot.transform);
        for(int z=15;z<850;z+=38)
        {
            Cube("Blue Track Light", new Vector3(-8f,1.5f,z), new Vector3(.25f,2.5f,.25f), new Color(.02f,.5f,1f), worldRoot.transform);
            Cube("Pink Track Light", new Vector3(8f,1.5f,z+14), new Vector3(.25f,2.5f,.25f), new Color(1f,.03f,.45f), worldRoot.transform);
        }
        for(int z=0;z<900;z+=45)
        {
            Cube("Trackside Block L", new Vector3(-12, .5f,z+20), new Vector3(4,1,5), new Color(.035f,.08f,.16f), worldRoot.transform);
            Cube("Trackside Block R", new Vector3(12, .5f,z+20), new Vector3(4,1,5), new Color(.035f,.08f,.16f), worldRoot.transform);
        }
        Cube("Finish Line", new Vector3(0,.09f,raceLength), new Vector3(12,.04f,1.2f), Color.white, worldRoot.transform);
        for(int x=-5;x<=5;x++)
            Cube("Finish Checker", new Vector3(x,.12f,raceLength), new Vector3(1,.035f,.8f), ((x+5)%2==0)?Color.black:Color.white, worldRoot.transform);
        playerCar = MakeCar("Player Car", carColors[selectedCar], playerStart);
        rivalCar = MakeCar("AI Rival", new Color(.85f,.04f,.13f), rivalStart);
        playerTransform=playerCar.transform; rivalTransform=rivalCar.transform;
        SetWorldForMenu();
    }

    GameObject MakeCar(string name, Color color, Vector3 pos)
    {
        GameObject root = new GameObject(name);
        root.transform.position=pos;
        GameObject body=Cube("Body",new Vector3(0,.25f,0),new Vector3(1.55f,.42f,3.1f),color,root.transform);
        Cube("Cabin",new Vector3(0,.58f,-.25f),new Vector3(1.12f,.45f,1.25f),new Color(.035f,.08f,.13f),root.transform);
        Cube("Front Bumper",new Vector3(0,.16f,1.58f),new Vector3(1.45f,.18f,.18f),new Color(.15f,.18f,.22f),root.transform);
        Cube("Rear Bumper",new Vector3(0,.16f,-1.58f),new Vector3(1.45f,.18f,.18f),new Color(.15f,.18f,.22f),root.transform);
        for(int side=-1;side<=1;side+=2)
        for(int z=-1;z<=1;z+=2)
        {
            GameObject wheel=GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            wheel.name="Wheel"; wheel.transform.SetParent(root.transform);
            wheel.transform.localPosition=new Vector3(side*.82f,.08f,z*1.02f);
            wheel.transform.localRotation=Quaternion.Euler(0,0,90);
            wheel.transform.localScale=new Vector3(.25f,.16f,.25f);
            wheel.GetComponent<Renderer>().material=Mat(new Color(.012f,.015f,.02f),.1f,.25f);
        }
        Cube("Headlight L",new Vector3(-.48f,.28f,1.58f),new Vector3(.28f,.12f,.05f),new Color(.45f,.85f,1f),root.transform);
        Cube("Headlight R",new Vector3(.48f,.28f,1.58f),new Vector3(.28f,.12f,.05f),new Color(.45f,.85f,1f),root.transform);
        return root;
    }

    void SetWorldForMenu()
    {
        if(playerCar!=null) { playerCar.transform.position=new Vector3(-1.8f,.4f,3f); playerCar.transform.rotation=Quaternion.Euler(0,18,0); }
        if(rivalCar!=null) { rivalCar.transform.position=new Vector3(1.8f,.4f,5f); rivalCar.transform.rotation=Quaternion.Euler(0,-18,0); }
        if(cam!=null) { cam.transform.position=new Vector3(0,5.2f,-7.5f); cam.transform.rotation=Quaternion.Euler(22,0,0); }
    }

    void ResetRaceWorld()
    {
        playerTransform.position=playerStart; playerTransform.rotation=Quaternion.identity;
        rivalTransform.position=rivalStart; rivalTransform.rotation=Quaternion.identity;
        playerDistance=0; rivalDistance=0; playerSpeed=0; rivalSpeed=0; elapsed=0; nitroFuel=1;
        gasHeld=brakeHeld=leftHeld=rightHeld=nitroHeld=false; raceFinished=false; raceRunning=false;
        countdown=3.0f; startTime=Time.time;
        cam.transform.position=new Vector3(0,5.5f,-8f); cam.transform.rotation=Quaternion.Euler(18,0,0);
    }

    void UpdateRace()
    {
        if(countdown>0)
        {
            countdown-=Time.deltaTime;
            if(hudCountdown) hudCountdown.text=countdown>2?"3":countdown>1?"2":"1";
            if(countdown<=0) { raceRunning=true; startTime=Time.time; if(hudCountdown) hudCountdown.text="GO!"; }
            return;
        }
        if(!raceRunning) return;
        elapsed+=Time.deltaTime;
        bool keyboardGas=Input.GetKey(KeyCode.W)||Input.GetKey(KeyCode.UpArrow);
        bool keyboardBrake=Input.GetKey(KeyCode.S)||Input.GetKey(KeyCode.DownArrow);
        bool keyboardLeft=Input.GetKey(KeyCode.A)||Input.GetKey(KeyCode.LeftArrow);
        bool keyboardRight=Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.RightArrow);
        bool accelerating=gasHeld||keyboardGas;
        bool braking=brakeHeld||keyboardBrake;
        steer=(leftHeld||keyboardLeft?-1:0)+(rightHeld||keyboardRight?1:0);
        float maxSpeed=175f+engineLevel*14f;
        if(accelerating) playerSpeed+= (42f+engineLevel*4f)*Time.deltaTime;
        else playerSpeed-=12f*Time.deltaTime;
        if(braking) playerSpeed-=70f*Time.deltaTime;
        if(nitroHeld && nitroFuel>0 && (accelerating||keyboardGas)) { playerSpeed+=80f*Time.deltaTime; nitroFuel-=.28f*Time.deltaTime; }
        else nitroFuel=Mathf.Min(1,nitroFuel+.07f*Time.deltaTime);
        playerSpeed=Mathf.Clamp(playerSpeed,0,maxSpeed+(nitroHeld?60:0));
        playerDistance+=playerSpeed*Time.deltaTime*.85f;
        playerTransform.position=new Vector3(Mathf.Clamp(playerTransform.position.x+steer*5f*Time.deltaTime,-4.7f,4.7f),.4f,playerDistance);
        playerTransform.rotation=Quaternion.Euler(0,steer*-4f,0);
        rivalSpeed=Mathf.Lerp(rivalSpeed,160f,Time.deltaTime*.25f);
        rivalDistance+=rivalSpeed*Time.deltaTime*.85f;
        rivalTransform.position=new Vector3(2f,.4f,rivalDistance);
        cam.transform.position=Vector3.Lerp(cam.transform.position,new Vector3(playerTransform.position.x*.35f,5.4f,playerDistance-8f),Time.deltaTime*3f);
        cam.transform.LookAt(playerTransform.position+new Vector3(0,.4f,10f));
        if(hudSpeed) hudSpeed.text=Mathf.RoundToInt(playerSpeed*1.6f)+" KM/H";
        if(hudProgress) hudProgress.text=Mathf.Clamp(Mathf.RoundToInt(playerDistance/raceLength*100),0,100)+"%";
        if(hudTimer) hudTimer.text=elapsed.ToString("00.00")+" s";
        if(hudNitro) hudNitro.text="NITRO "+Mathf.RoundToInt(nitroFuel*100)+"%";
        if(playerDistance>=raceLength || rivalDistance>=raceLength) FinishRace();
    }

    void FinishRace()
    {
        raceFinished=true; raceRunning=false; races++;
        bool won=playerDistance>=rivalDistance;
        if(won) { wins++; credits+=750; resultMessage="VICTORY!  +750 CREDITS"; }
        else { credits+=250; resultMessage="RACE COMPLETE  +250 CREDITS"; }
        SaveData();
        ShowScreen(Screen.Results);
    }

    void SetupUI()
    {
        GameObject ev=GameObject.FindObjectOfType<EventSystem>()?.gameObject;
        if(ev==null) { ev=new GameObject("EventSystem"); ev.AddComponent<EventSystem>(); ev.AddComponent<StandaloneInputModule>(); }
        GameObject c=new GameObject("Game UI"); canvas=c.AddComponent<Canvas>(); canvas.renderMode=RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler=c.AddComponent<CanvasScaler>(); scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution=new Vector2(1920,1080); scaler.matchWidthOrHeight=.5f;
        c.AddComponent<GraphicRaycaster>();
        menuRoot=NewPanel("Menu Root",new Color(.015f,.035f,.09f,.94f));
        panelRoot=NewPanel("Panel Root",new Color(.015f,.035f,.09f,.96f));
        raceHud=NewPanel("Race HUD",new Color(0,0,0,0));
        titleText=MakeText(menuRoot.transform,"DRAG LEGENDS",64,TextAnchor.MiddleCenter,new Vector2(.5f,.83f),new Vector2(.8f,.12f),new Color(.2f,.75f,1f));
        MakeText(menuRoot.transform,"M O B I L E   •   R A C I N G   E V O L V E D",22,TextAnchor.MiddleCenter,new Vector2(.5f,.75f),new Vector2(.8f,.05f),Color.white);
        MakeText(menuRoot.transform,"OFFLINE DRAG RACING",20,TextAnchor.MiddleCenter,new Vector2(.5f,.59f),new Vector2(.7f,.05f),new Color(.8f,.85f,1));
        MakeButton(menuRoot.transform,"QUICK RACE",new Vector2(.5f,.47f),new Vector2(.32f,.075f),new Color(0,.55f,1),()=>StartRace());
        MakeButton(menuRoot.transform,"GARAGE  /  CARS",new Vector2(.5f,.37f),new Vector2(.32f,.065f),new Color(.4f,.1f,.9f),()=>ShowScreen(Screen.Garage));
        MakeButton(menuRoot.transform,"UPGRADES",new Vector2(.5f,.285f),new Vector2(.32f,.065f),new Color(0,.5f,.28f),()=>ShowScreen(Screen.Upgrades));
        MakeButton(menuRoot.transform,"STATS",new Vector2(.5f,.20f),new Vector2(.15f,.055f),new Color(.1f,.2f,.35f),()=>ShowScreen(Screen.Stats));
        MakeButton(menuRoot.transform,"SETTINGS",new Vector2(.66f,.20f),new Vector2(.15f,.055f),new Color(.1f,.2f,.35f),()=>ShowScreen(Screen.Settings));
        MakeText(menuRoot.transform,"CREDITS: "+credits,22,TextAnchor.MiddleCenter,new Vector2(.5f,.105f),new Vector2(.5f,.05f),new Color(1,.75f,.1f));

        hudSpeed=MakeText(raceHud.transform,"0 KM/H",32,TextAnchor.MiddleLeft,new Vector2(.12f,.91f),new Vector2(.22f,.07f),Color.white);
        hudProgress=MakeText(raceHud.transform,"0%",26,TextAnchor.MiddleCenter,new Vector2(.5f,.92f),new Vector2(.2f,.06f),Color.white);
        hudTimer=MakeText(raceHud.transform,"00.00 s",26,TextAnchor.MiddleRight,new Vector2(.87f,.91f),new Vector2(.2f,.06f),Color.white);
        hudCountdown=MakeText(raceHud.transform,"",68,TextAnchor.MiddleCenter,new Vector2(.5f,.66f),new Vector2(.3f,.15f),new Color(1,.8f,.1f));
        hudNitro=MakeText(raceHud.transform,"NITRO 100%",20,TextAnchor.MiddleCenter,new Vector2(.5f,.13f),new Vector2(.22f,.05f),new Color(.1f,.8f,1));
        MakeTouchButton("◀",new Vector2(.10f,.18f),new Vector2(.11f,.12f),()=>leftHeld=true,()=>leftHeld=false);
        MakeTouchButton("▶",new Vector2(.23f,.18f),new Vector2(.11f,.12f),()=>rightHeld=true,()=>rightHeld=false);
        MakeTouchButton("BRAKE",new Vector2(.72f,.18f),new Vector2(.12f,.12f),()=>brakeHeld=true,()=>brakeHeld=false);
        MakeTouchButton("GAS",new Vector2(.86f,.20f),new Vector2(.14f,.16f),()=>gasHeld=true,()=>gasHeld=false);
        MakeTouchButton("NITRO",new Vector2(.86f,.38f),new Vector2(.12f,.09f),()=>nitroHeld=true,()=>nitroHeld=false);
        HideAll();
    }

    GameObject NewPanel(string name, Color color)
    {
        GameObject g=new GameObject(name,typeof(RectTransform),typeof(Image));
        g.transform.SetParent(canvas.transform,false);
        RectTransform r=g.GetComponent<RectTransform>(); r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=Vector2.zero;r.offsetMax=Vector2.zero;
        Image im=g.GetComponent<Image>(); im.color=color; im.raycastTarget=false;
        return g;
    }

    Text MakeText(Transform parent,string value,int size,TextAnchor anchor,Vector2 pos,Vector2 dimensions,Color color)
    {
        GameObject g=new GameObject("Text - "+value,typeof(RectTransform),typeof(Text));
        g.transform.SetParent(parent,false);
        RectTransform r=g.GetComponent<RectTransform>();r.anchorMin=pos;r.anchorMax=pos;r.sizeDelta=dimensions;r.anchoredPosition=Vector2.zero;
        Text t=g.GetComponent<Text>();t.text=value;t.font=font;t.fontSize=size;t.alignment=anchor;t.color=color;t.resizeTextForBestFit=true;t.resizeTextMinSize=12;t.resizeTextMaxSize=size;t.horizontalOverflow=HorizontalWrapMode.Wrap;t.verticalOverflow=VerticalWrapMode.Overflow;
        return t;
    }

    Button MakeButton(Transform parent,string label,Vector2 pos,Vector2 dimensions,Color color,UnityEngine.Events.UnityAction action)
    {
        GameObject g=new GameObject("Button - "+label,typeof(RectTransform),typeof(Image),typeof(Button));
        g.transform.SetParent(parent,false);
        RectTransform r=g.GetComponent<RectTransform>();r.anchorMin=pos;r.anchorMax=pos;r.sizeDelta=dimensions;r.anchoredPosition=Vector2.zero;
        Image im=g.GetComponent<Image>();im.color=color;
        Button b=g.GetComponent<Button>();b.targetGraphic=im;b.onClick.AddListener(action);
        MakeText(g.transform,label,24,TextAnchor.MiddleCenter,new Vector2(.5f,.5f),dimensions,Color.white);
        return b;
    }

    void MakeTouchButton(string label,Vector2 pos,Vector2 dimensions,UnityEngine.Events.UnityAction down,UnityEngine.Events.UnityAction up)
    {
        Button b=MakeButton(raceHud.transform,label,pos,dimensions,new Color(.03f,.15f,.3f,.82f),()=>{});
        EventTrigger tr=b.gameObject.AddComponent<EventTrigger>();
        EventTrigger.Entry e1=new EventTrigger.Entry();e1.eventID=EventTriggerType.PointerDown;e1.callback.AddListener((data)=>down());tr.triggers.Add(e1);
        EventTrigger.Entry e2=new EventTrigger.Entry();e2.eventID=EventTriggerType.PointerUp;e2.callback.AddListener((data)=>up());tr.triggers.Add(e2);
    }

    void HideAll()
    {
        if(menuRoot)menuRoot.SetActive(false);
        if(panelRoot)panelRoot.SetActive(false);
        if(raceHud)raceHud.SetActive(false);
    }

    void ShowScreen(Screen s)
    {
        currentScreen=s; HideAll();
        if(s==Screen.Menu)
        {
            menuRoot.SetActive(true); SetWorldForMenu();
            titleText.text="DRAG LEGENDS";
            Text[] ts=menuRoot.GetComponentsInChildren<Text>(true);
            foreach(Text t in ts) if(t.text.StartsWith("CREDITS:")) t.text="CREDITS: "+credits;
        }
        else if(s==Screen.Race) { raceHud.SetActive(true); }
        else
        {
            panelRoot.SetActive(true);
            foreach(Transform ch in panelRoot.transform) Destroy(ch.gameObject);
            if(s==Screen.Garage) BuildGarage();
            if(s==Screen.Upgrades) BuildUpgrades();
            if(s==Screen.Stats) BuildStats();
            if(s==Screen.Settings) BuildSettings();
            if(s==Screen.Results) BuildResults();
        }
    }

    void Header(string title)
    {
        MakeText(panelRoot.transform,title,48,TextAnchor.MiddleCenter,new Vector2(.5f,.86f),new Vector2(.8f,.1f),new Color(.2f,.75f,1));
        MakeButton(panelRoot.transform,"BACK",new Vector2(.12f,.90f),new Vector2(.14f,.06f),new Color(.12f,.2f,.32f),()=>ShowScreen(Screen.Menu));
    }

    void BuildGarage()
    {
        Header("GARAGE");
        MakeText(panelRoot.transform,carNames[selectedCar],36,TextAnchor.MiddleCenter,new Vector2(.5f,.67f),new Vector2(.6f,.08f),Color.white);
        MakeText(panelRoot.transform,"Select a ride. Each car has a distinct paint finish.",20,TextAnchor.MiddleCenter,new Vector2(.5f,.60f),new Vector2(.8f,.05f),Color.gray);
        for(int i=0;i<4;i++)
        {
            int idx=i;
            MakeButton(panelRoot.transform,carNames[i],new Vector2(.2f+i*.2f,.45f),new Vector2(.17f,.09f),carColors[i],()=>SelectCar(idx));
        }
        MakeButton(panelRoot.transform,"UPGRADE THIS CAR",new Vector2(.5f,.29f),new Vector2(.32f,.08f),new Color(0,.55f,.28f),()=>ShowScreen(Screen.Upgrades));
        MakeText(panelRoot.transform,"Credits: "+credits,24,TextAnchor.MiddleCenter,new Vector2(.5f,.18f),new Vector2(.5f,.05f),new Color(1,.75f,.1f));
    }

    void SelectCar(int i)
    {
        selectedCar=i; SaveData();
        if(playerCar!=null) playerCar.transform.Find("Body").GetComponent<Renderer>().material=Mat(carColors[i],.15f,.45f);
        BuildGarage();
    }

    void BuildUpgrades()
    {
        Header("PERFORMANCE LAB");
        MakeText(panelRoot.transform,"Tune your machine for the quarter mile.",22,TextAnchor.MiddleCenter,new Vector2(.5f,.72f),new Vector2(.7f,.06f),Color.white);
        MakeText(panelRoot.transform,"ENGINE  •  Level "+engineLevel+"  •  + acceleration",24,TextAnchor.MiddleCenter,new Vector2(.5f,.61f),new Vector2(.7f,.06f),Color.white);
        MakeButton(panelRoot.transform,"UPGRADE ENGINE  -  "+(engineLevel*500),new Vector2(.5f,.54f),new Vector2(.32f,.065f),new Color(.02f,.4f,.7f),()=>BuyUpgrade("engine"));
        MakeText(panelRoot.transform,"GRIP  •  Level "+gripLevel+"  •  better control",24,TextAnchor.MiddleCenter,new Vector2(.5f,.43f),new Vector2(.7f,.06f),Color.white);
        MakeButton(panelRoot.transform,"UPGRADE GRIP  -  "+(gripLevel*400),new Vector2(.5f,.36f),new Vector2(.32f,.065f),new Color(.35f,.15f,.7f),()=>BuyUpgrade("grip"));
        MakeText(panelRoot.transform,"NITRO  •  Level "+nitroLevel+"  •  boost capacity",24,TextAnchor.MiddleCenter,new Vector2(.5f,.25f),new Vector2(.7f,.06f),Color.white);
        MakeButton(panelRoot.transform,"UPGRADE NITRO  -  "+(nitroLevel*350),new Vector2(.5f,.18f),new Vector2(.32f,.065f),new Color(0,.5f,.28f),()=>BuyUpgrade("nitro"));
        MakeText(panelRoot.transform,"Credits: "+credits,22,TextAnchor.MiddleCenter,new Vector2(.82f,.08f),new Vector2(.25f,.05f),new Color(1,.75f,.1f));
    }

    void BuyUpgrade(string kind)
    {
        int cost=kind=="engine"?engineLevel*500:kind=="grip"?gripLevel*400:nitroLevel*350;
        if(credits<cost) { resultMessage="NOT ENOUGH CREDITS"; return; }
        credits-=cost;
        if(kind=="engine")engineLevel++; else if(kind=="grip")gripLevel++; else nitroLevel++;
        SaveData(); BuildUpgrades();
    }

    void BuildStats()
    {
        Header("DRIVER PROFILE");
        MakeText(panelRoot.transform,"RACES  "+races,32,TextAnchor.MiddleCenter,new Vector2(.5f,.66f),new Vector2(.6f,.07f),Color.white);
        MakeText(panelRoot.transform,"WINS  "+wins,32,TextAnchor.MiddleCenter,new Vector2(.5f,.55f),new Vector2(.6f,.07f),new Color(1,.75f,.1f));
        MakeText(panelRoot.transform,"WIN RATE  "+(races==0?0:Mathf.RoundToInt((float)wins/races*100))+"%",32,TextAnchor.MiddleCenter,new Vector2(.5f,.44f),new Vector2(.6f,.07f),Color.white);
        MakeText(panelRoot.transform,"CREDITS  "+credits,28,TextAnchor.MiddleCenter,new Vector2(.5f,.33f),new Vector2(.6f,.07f),new Color(1,.75f,.1f));
        MakeButton(panelRoot.transform,"RACE AGAIN",new Vector2(.5f,.20f),new Vector2(.28f,.07f),new Color(0,.5f,.25f),()=>StartRace());
    }

    void BuildSettings()
    {
        Header("SETTINGS");
        MakeText(panelRoot.transform,"Audio toggle: "+(soundOn?"ON":"OFF"),28,TextAnchor.MiddleCenter,new Vector2(.5f,.62f),new Vector2(.6f,.07f),Color.white);
        MakeButton(panelRoot.transform,"TOGGLE SOUND",new Vector2(.5f,.52f),new Vector2(.3f,.07f),new Color(.1f,.25f,.45f),()=>{soundOn=!soundOn;AudioListener.volume=soundOn?1:0;SaveData();BuildSettings();});
        MakeText(panelRoot.transform,"Landscape controls: keyboard in Editor, touch buttons on Android.",20,TextAnchor.MiddleCenter,new Vector2(.5f,.38f),new Vector2(.8f,.08f),Color.gray);
        MakeText(panelRoot.transform,"Progress is saved locally on this device.",20,TextAnchor.MiddleCenter,new Vector2(.5f,.28f),new Vector2(.8f,.05f),Color.gray);
    }

    void BuildResults()
    {
        Header("RACE RESULTS");
        MakeText(panelRoot.transform,resultMessage,40,TextAnchor.MiddleCenter,new Vector2(.5f,.67f),new Vector2(.8f,.1f),new Color(1,.75f,.1f));
        MakeText(panelRoot.transform,"TIME  "+elapsed.ToString("00.00")+" s",30,TextAnchor.MiddleCenter,new Vector2(.5f,.55f),new Vector2(.6f,.07f),Color.white);
        MakeText(panelRoot.transform,"DISTANCE  "+Mathf.RoundToInt(playerDistance)+" m",24,TextAnchor.MiddleCenter,new Vector2(.5f,.46f),new Vector2(.6f,.06f),Color.white);
        MakeText(panelRoot.transform,"CREDITS  "+credits,26,TextAnchor.MiddleCenter,new Vector2(.5f,.37f),new Vector2(.6f,.06f),new Color(1,.75f,.1f));
        MakeButton(panelRoot.transform,"RACE AGAIN",new Vector2(.38f,.22f),new Vector2(.24f,.075f),new Color(0,.55f,.25f),()=>StartRace());
        MakeButton(panelRoot.transform,"MAIN MENU",new Vector2(.63f,.22f),new Vector2(.24f,.075f),new Color(.1f,.25f,.45f),()=>ShowScreen(Screen.Menu));
    }

    void StartRace()
    {
        ShowScreen(Screen.Race);
        ResetRaceWorld();
    }

    void LoadData()
    {
        credits=PlayerPrefs.GetInt("dl_credits",2500);
        selectedCar=PlayerPrefs.GetInt("dl_car",0);
        engineLevel=PlayerPrefs.GetInt("dl_engine",1);
        gripLevel=PlayerPrefs.GetInt("dl_grip",1);
        nitroLevel=PlayerPrefs.GetInt("dl_nitro",1);
        races=PlayerPrefs.GetInt("dl_races",0); wins=PlayerPrefs.GetInt("dl_wins",0);
        soundOn=PlayerPrefs.GetInt("dl_sound",1)==1;
        selectedCar=Mathf.Clamp(selectedCar,0,3);
    }

    void SaveData()
    {
        PlayerPrefs.SetInt("dl_credits",credits);PlayerPrefs.SetInt("dl_car",selectedCar);
        PlayerPrefs.SetInt("dl_engine",engineLevel);PlayerPrefs.SetInt("dl_grip",gripLevel);PlayerPrefs.SetInt("dl_nitro",nitroLevel);
        PlayerPrefs.SetInt("dl_races",races);PlayerPrefs.SetInt("dl_wins",wins);PlayerPrefs.SetInt("dl_sound",soundOn?1:0);
        PlayerPrefs.Save();
    }
}
